package com.calculator.calculatorTest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;

@SpringBootApplication(scanBasePackages = {"com"})
@EnableCaching
public class CalculatorTestApplication {
	public static void main(String[] args) {
		SpringApplication.run(CalculatorTestApplication.class, args);
	}
}
