package com.calculator.businessService;

import java.util.HashMap;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.calculator.controller.calculatorController;
import com.calculator.exceptionHandling.CustomGenericException;

@Service
public class CalculatorBusinessLogic {

	final static Logger logger = LogManager.getLogger(calculatorController.class);

	@Cacheable(value = "calculate", key = "#firstNumber+'_'+#secondNumber+'_'+#operation")
	public ResponseEntity<Map<String, Object>> calculate(double firstNumber, double secondNumber, String operation) {
		Map<String, Object> finalresult = new HashMap<>();
		double result;
		/*
		 * if(!operation.equals(operation.toUpperCase())) {
		 * operation=operation.toUpperCase(); }
		 */

		try {
			switch (operation) {
			case "ADDITION":
				logger.info("Operation addition started");
				result = firstNumber + secondNumber;
				break;
			case "SUBSTRACTION":
				logger.info("Operation Substraction started");
				result = firstNumber - secondNumber;
				break;
			case "MULTIPLICATION":
				logger.info("Operation Multiplication started");
				result = firstNumber * secondNumber;
				break;
			case "DIVISION":
				if (secondNumber == 0) {
					throw new CustomGenericException("Cannot divide by zero");
			
				} else
					logger.info("Operation division started");
				result = firstNumber / secondNumber;
				break;
			default:
				throw new CustomGenericException("Invalid Operation");
			}
		} catch (CustomGenericException c) {
			Map<String, Object> errorMap = new HashMap<>();
			errorMap.put("Error", c.getMessage());
			return new ResponseEntity<Map<String, Object>>(errorMap, HttpStatus.BAD_REQUEST);
		}
		finalresult.put("result", result);
		logger.info("Calculated response sending ");
		return new ResponseEntity<Map<String, Object>>(finalresult, HttpStatus.OK);

	}
}
