package com.calculator.exceptionHandling;

public class CustomGenericException extends RuntimeException {

	
	private static final long serialVersionUID = 1L;

	public CustomGenericException() {
		super();
	}

	public CustomGenericException(String message) {
		super(message);
	}

}
