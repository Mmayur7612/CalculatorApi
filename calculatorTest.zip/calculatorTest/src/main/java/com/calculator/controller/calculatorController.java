package com.calculator.controller;

import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.core.Response;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.calculator.businessService.CalculatorBusinessLogic;
import com.calculator.calculatorTest.CalculatorTestApplication;
import com.calculator.exceptionHandling.CustomGenericException;

@RestController

public class calculatorController {

	final static Logger logger = LogManager.getLogger(calculatorController.class);
	@Autowired
	CalculatorBusinessLogic calculator;

	@CrossOrigin
	@ResponseStatus(HttpStatus.OK)
	@GetMapping("/calculator")
	public ResponseEntity<?> getamount(@RequestParam("firstNumber") double firstNumber,
			@RequestParam("secondNumber") double secondNumber, @RequestParam("operation") String operation) {
		logger.info("Arithmetic Operation Started");
		try {
			if (operation.isEmpty() || operation == null) {
				logger.error("operation Is Blank");
				throw new CustomGenericException(operation);
			} else {
				logger.info("Calling calculate method");
				return calculator.calculate(firstNumber, secondNumber, operation.toUpperCase());
			}
		} catch (CustomGenericException ex) {
			Map<String, Object> errorMap = new HashMap<>();
			errorMap.put("Error", "Provided Operation is Blank");
			logger.error("Error Response Sending");
			return new ResponseEntity<Map<String, Object>>(errorMap, HttpStatus.BAD_REQUEST);
		}
		

	}

}
